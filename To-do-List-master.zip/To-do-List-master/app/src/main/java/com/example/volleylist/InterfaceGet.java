package com.example.volleylist;

public interface InterfaceGet {


}
